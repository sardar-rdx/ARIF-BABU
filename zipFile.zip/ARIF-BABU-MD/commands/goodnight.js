const fetch = require('node-fetch');
const S = require('../lib/style');

async function goodnightCommand(sock, chatId, message) {
    try {
        const shizokeys = 'shizo';
        const res = await fetch(`https://shizoapi.onrender.com/api/texts/lovenight?apikey=${shizokeys}`);
        
        if (!res.ok) {
            throw await res.text();
        }
        
        const json = await res.json();
        const goodnightMessage = json.result;

        // Send the goodnight message
        await sock.sendMessage(chatId, { text: S.panel({
            title: 'GOODNIGHT',
            icon: '🌙',
            lines: [goodnightMessage]
        }) }, { quoted: message });
    } catch (error) {
        console.error('Error in goodnight command:', error);
        await sock.sendMessage(chatId, { text: S.error('ERROR', 'Failed to get goodnight message. Please try again later.') }, { quoted: message });
    }
}

module.exports = { goodnightCommand }; 
